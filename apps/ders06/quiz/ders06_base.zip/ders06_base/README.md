*Ders 05* kapsamında,

* Uygulamamızı bir sunucu üzerinden erişilebilir hale getirdik.
* React-router ile yönlendirme işlemleri yaptık.
