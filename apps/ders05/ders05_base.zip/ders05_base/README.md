*Ders 03* kapsamında,

* İlk olarak App isimli bir component oluşturarak kontrolü React'a bıraktı.
* Bu component içerisinde soru çekme ve soruyu görüntüleme işlemleri yaptık.
  * renderAnswerTag fonksiyonu güncellendi.
  * handleClick fonksiyonu eklendi
