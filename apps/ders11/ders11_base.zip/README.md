*Ders 11* kapsamında,

* matches ve matches/ongoing endpointleri ile oyunu yarım bırakma, yarım kalan oyunu devam ettirme ve galibiyet/mağlubiyet sayılarını tutmak gibi çeşitli eylemler gerçekleştirilecektir.
* Ayrıca websocket ile mevcut bağlı kullanıcı sayısının takibi yapılacaktır.
* POST /api/matches ile oyun başlatılabilir
* POST /api/matches/ongoing ile doğru cevap gönderilebilir
* GET /api/matches/ongoing ile devam eden oyun çekilebilir
